# include "common.h"

int main(int argc, char const *argv[])
{
    int choice;
    
    init_menu ();
    while (1)
    {
        scanf ("%d", &choice);
        switch (choice)
        {
            case 1:
                person_person ();
                break;
            case 2:
                replay_chess ();
                break;
            case 3:
                printf ("期待与您的下次相遇。\n");
                exit (0);
                break;
            default:
                printf ("无效选择,请再次输入： \n");
        }
    }
    return 0;
}
