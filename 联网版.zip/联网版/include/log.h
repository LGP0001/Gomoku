# ifndef LOG_H
# define LOG_H

void InitLogger(const char *path, bool server); 
void LogError(const char *message);
void LogInfo(const char *message);
void LogWarning(const char *message);
void LogDebug(const char *message);

# endif // LOG_H
